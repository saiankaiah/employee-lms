from django.apps import AppConfig


class LeaveConfig(AppConfig):
    name = 'leave'
