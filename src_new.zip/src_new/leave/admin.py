from django.contrib import admin
from .models import Leave
# from .models import Comment


admin.site.register(Leave)
# admin.site.register(Comment)